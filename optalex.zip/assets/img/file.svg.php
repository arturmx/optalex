<svg  id="Component_40_1" data-name="Component 40 – 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18" height="24" viewBox="0 0 18 24">
																											<defs>
																												<clipPath id="clip-path">
																													<rect id="Rectangle_246" data-name="Rectangle 246" width="18" height="24" fill="none" stroke="#707070" class="about-download-svg-color" stroke-linejoin="round" stroke-width="1"/>
																												</clipPath>
																											</defs>
																											<g id="Group_1315" data-name="Group 1315">
																												<g id="Group_1314" data-name="Group 1314" clip-path="url(#clip-path)">
																												<path id="Path_579" data-name="Path 579" d="M17.054,23.073H.5V.5H12.539l4.515,4.515Z" transform="translate(0.252 0.252)" fill="none" stroke="#707070" class="about-download-svg-color" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1"/>
																												</g>
																											</g>
																											<line id="Line_5" data-name="Line 5" x2="6.02" transform="translate(4.515 8.076)" fill="none" stroke="#707070" class="about-download-svg-color" stroke-miterlimit="10" stroke-width="1"/>
																											<line id="Line_6" data-name="Line 6" x2="9.029" transform="translate(4.515 12.322)" fill="none" stroke="#707070" class="about-download-svg-color" stroke-miterlimit="10" stroke-width="1"/>
																											<line id="Line_7" data-name="Line 7" x2="9" transform="translate(5 17)" fill="none" stroke="#707070" class="about-download-svg-color" stroke-miterlimit="10" stroke-width="1"/>
																										</svg>